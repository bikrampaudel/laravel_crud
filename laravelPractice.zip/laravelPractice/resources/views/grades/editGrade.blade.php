<!DOCTYPE html>
<html>
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
  <div class="container">
  <div class="row">
     @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
@if(Session::has('flash_message'))
    <div class="alert alert-success">
        {{ Session::get('flash_message') }}
    </div>
@endif
   <h1>Editing "{{ $grade->name }}"</h1>
  <p class="lead">Edit and save this grade below, or <a href="{{ route('grades.index') }}">go back to all grades.</a></p>
  <hr>
    {!! Form::model($grade, [
    'method' => 'PATCH',
    'route' => ['grades.update', $grade->id]
]) !!}  
      <div class="form-group">
        {!!Form::label('name', 'Name')!!}
         {{ Form::text('name', null, ['class'=>'form-control',
          'placeholder'=>'Enter your grade','id'=>'name'])}} 
      </div>
   <div class="form-group">
      {!!Form::label('discription', 'Description')!!}
     {{Form::select('discription', ['nine'=>'nine standard','ten'=>'ten standard','eleven'=>'eleven standard'],'$id->discription',['class'=>'form-control'])}}
   </div>
    <div class="form-group">
 <div class="form-group">
      {!! Form::submit('Update Grade', ['class'=>'btn btn-primary'])!!}
 
 </div>
 {!! Form::close() !!}
   
</div>
   </div>
</body>
</html>