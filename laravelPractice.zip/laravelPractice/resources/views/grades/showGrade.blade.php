<!DOCTYPE html>
<html>
<head>
    <title>Show Grade</title>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container horizontal">
  <fieldset>
    <legend class="col-lg-offset-4 col-lg-4">View Grade!!</legend>
    </fieldset>
<p class="lead">View the grade below, or <a href="{{ route('grades.index') }}">go back to all grades.</a></p>
<h2>Name:{{ $grade->name }}</h2>
    <h3><i>Id:</i>{{ $grade->id}}</h3>
    <h3><i>Discription:</i>{{ $grade->discription}}<h3>
    
    <p>
<a href="{{ route('grades.edit', $grade->id) }}" class="btn btn-primary">Edit grade</a>
<div>
        {!! Form::open([
            'method' => 'DELETE',
            'route' => ['grades.destroy', $grade->id]
        ]) !!}
            {!! Form::submit('Delete grade', ['class' => 'btn btn-danger']) !!}
        {!! Form::close() !!}
    </div>
  </p>
</div>
</body>
</html>