<!DOCTYPE html>
<html>
<head>
    <title>Show Grade</title>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container horizontal">
  <fieldset>
    <legend class="col-lg-offset-4 col-lg-4">View Leader!!</legend>
    </fieldset>
<p class="lead">View the leader below, or <a href="{{ route('leaders.index') }}">go back to all leaders.</a></p>
<h2>Name:{{ $leader->name }}</h2>
    <h3><i>Id:</i>{{ $leader->id}}</h3>
    <h3><i>Grade Id:</i>{{ $leader->grade_id}}<h3>
    
    <p>
<a href="{{ route('leaders.edit', $leader->id) }}" class="btn btn-primary">Edit Leader</a>
<div>
        {!! Form::open([
            'method' => 'DELETE',
            'route' => ['leaders.destroy', $leader->id]
        ]) !!}
            {!! Form::submit('Delete Leader', ['class' => 'btn btn-danger']) !!}
        {!! Form::close() !!}
    </div>
  </p>
</div>
</body>
</html>