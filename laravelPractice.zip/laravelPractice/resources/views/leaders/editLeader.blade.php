<!DOCTYPE html>
<html>
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
  <div class="container">
  <div class="row">
     @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
@if(Session::has('flash_message'))
    <div class="alert alert-success">
        {{ Session::get('flash_message') }}
    </div>
@endif
   <h1>Editing "{{ $leader->name }}"</h1>
  <p class="lead">Edit and save this leader below, or <a href="{{ route('leaders.index') }}">go back to all leaders.</a></p>
  <hr>
    {!! Form::model($leader, [
    'method' => 'PATCH',
    'route' => ['leaders.update', $leader->id]
]) !!}  
     <div class="form-group">
        {!!Form::label('name', 'Name')!!}
         {{ Form::text('name', null, ['class'=>'form-control',
          'id'=>'name'])}} 
      </div>
   
  <div class="form-group">
    {!!Form::label('grade_id', 'Grade Id')!!}
     {{Form::text('grade_id', null,['class'=>'form-control'])}}
  </div>
 <div class="form-group">
      {!! Form::submit('Update Leader', ['class'=>'btn btn-primary'])!!}
 
 </div>
 {!! Form::close() !!}
   
</div>
   </div>
</body>
</html>