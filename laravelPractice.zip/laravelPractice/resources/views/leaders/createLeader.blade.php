<!DOCTYPE html>
<html>
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
  <div class="container">
    <div class="row">
      
  @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
 @if(Session::has('flash_message'))
    <div class="alert alert-success">
        {{ Session::get('flash_message') }}
    </div>
@endif
   <fieldset>
    <legend class="col-lg-offset-2 col-lg-2">Create Leader</legend>
    </fieldset>
    <p class="lead">Create the leader below, or <a href="{{ route('leaders.index') }}">go back to all leaders.</a></p>
    {!! Form::open(['url' => 'leaders', 'method' => 'post' , 'class'=>'form-horizontal']) !!}
      <div class="form-group">
        {!!Form::label('name', 'Name')!!}
         {{ Form::text('name', '', ['class'=>'form-control',
          'placeholder'=>'Enter leader name','id'=>'name'])}} 
      </div>
   
  <div class="form-group">
    {!!Form::label('grade_id', 'Grade Id')!!}
     {{Form::text('grade_id', '', ['class'=>'form-control','placeholder'=> 'Enter grade id'])}}
  </div>
 <div class="form-group">
      {!! Form::submit('Add Leader', ['class'=>'btn btn-primary'])!!}
 
 </div>
 {!! Form::close() !!}
   
</div>
   </div>
</body>
</html>