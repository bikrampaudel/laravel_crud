<!DOCTYPE html>
<html>
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
  <div class="container">
  <div class="row">
     @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
@if(Session::has('flash_message'))
    <div class="alert alert-success">
        {{ Session::get('flash_message') }}
    </div>
@endif
   <h1>Editing "{{ $student->name }}"</h1>
  <p class="lead">Edit and save this student below, or <a href="{{ route('students.index') }}">go back to all students.</a></p>
  <hr>
    {!! Form::model($student, [
    'method' => 'PATCH',
    'route' => ['students.update', $student->id]
]) !!}  
      <div class="form-group">
        {!!Form::label('name', 'Name')!!}
         {{ Form::text('name', null, ['class'=>'form-control',
          'placeholder'=>'Enter your name','id'=>'name'])}} 
      </div>
   <div class="form-group">
       {!!Form::label('address', 'Address')!!}
       {{ Form::text('address', null, ['class'=>'form-control',
   ' placeholder'=>'Enter your address','id'=>'address'])}} 
   </div>
    <div class="form-group">
      
     {!!Form::label('Gender', 'Gender')!!}
        <div class="radio-inline"><label> 
          {!! Form::radio('gender', 'male', true,['id'=>'optionsRadios1'])!!} Male</label></div>
        <div class="radio-inline"><label> 
          {!! Form::radio('gender', 'female', false,['id'=>'optionsRadios1'])!!} Female</label></div>
        <div class="radio-inline"><label> {!! Form::radio('gender', 'none', false,['id'=>'optionsRadios1'])!!} None</label></div>
      </div>
  
  
  <div class="form-group">
     {!!Form::label('hobbies', 'Hobbies')!!} <br />
     {!! Form::checkbox('hobbies', 'playing', '',['class'=>'col-lg-0']) !!}Playing <br />
    {{Form::checkbox('hobbies', 'programming' ,'',['class'=>'col-lg-0'])}} Programming <br />
     {{Form::checkbox('hobbies', 'dancing' , '', ['class'=>'col-lg-0'])}} Dancing <br />
  </div>
  <div class="form-group">
    {!!Form::label('nationality', 'Nationality')!!}
     {{Form::select('nationality',['nepal'=>'Nepali','india'=>'Indian','america'=>'American'],'nepal',['class'=>'form-control'])}}
  </div>
 <div class="form-group">
      {!! Form::submit('Update Student', ['class'=>'btn btn-primary'])!!}
 
 </div>
 {!! Form::close() !!}
   
</div>
   </div>
</body>
</html>