<!DOCTYPE html>
<html>
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
  <div class="container">
    <div class="row">
      
  @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
 @if(Session::has('flash_message'))
    <div class="alert alert-success">
        {{ Session::get('flash_message') }}
    </div>
@endif
   <fieldset>
    <legend class="col-lg-offset-2 col-lg-2">Create Teacher</legend>
    </fieldset>
    <p class="lead">Create the teacher below, or <a href="{{ route('teachers.index') }}">go back to all teachers.</a></p>
    {!! Form::open(['url' => 'teachers', 'method' => 'post' , 'class'=>'form-horizontal']) !!}
      <div class="form-group">
        {!!Form::label('name', 'Name')!!}
         {{ Form::text('name', '', ['class'=>'form-control',
          'placeholder'=>'Enter teacher name','id'=>'name'])}} 
      </div>
   
  <div class="form-group">
    {!!Form::label('address', 'Address')!!}
     {{Form::text('address', '', ['class'=>'form-control','placeholder'=> 'Enter teacher address'])}}
  </div>
 <div class="form-group">
      {!! Form::submit('Add Teacher', ['class'=>'btn btn-primary'])!!}
 
 </div>
 {!! Form::close() !!}
   
</div>
   </div>
</body>
</html>