<!DOCTYPE html>
<html>
<head>
    <title>Show Teacher</title>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container horizontal">
  <fieldset>
    <legend class="col-lg-offset-4 col-lg-4">View School!!</legend>
    </fieldset>
<p class="lead">View the school below, or <a href="{{ route('schools.index') }}">go back to all schools.</a></p>
<h2>Name:{{ $school->name }}</h2>
    <h3><i>Id:</i>{{ $school->id}}</h3>
    <h3><i>Address:</i>{{ $school->address}}<h3>
    
    <p>
<a href="{{ route('schools.edit', $school->id) }}" class="btn btn-primary">Edit School</a>
<div>
        {!! Form::open([
            'method' => 'DELETE',
            'route' => ['schools.destroy', $school->id]
        ]) !!}
            {!! Form::submit('Delete School', ['class' => 'btn btn-danger']) !!}
        {!! Form::close() !!}
    </div>
  </p>
</div>
</body>
</html>