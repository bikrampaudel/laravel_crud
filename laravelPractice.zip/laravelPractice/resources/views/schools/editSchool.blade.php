<!DOCTYPE html>
<html>
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
  <div class="container">
  <div class="row">
     @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
@if(Session::has('flash_message'))
    <div class="alert alert-success">
        {{ Session::get('flash_message') }}
    </div>
@endif
   <h1>Editing "{{ $school->name }}"</h1>
  <p class="lead">Edit and save this school below, or <a href="{{ route('schools.index') }}">go back to all schools.</a></p>
  <hr>
    {!! Form::model($school, [
    'method' => 'PATCH',
    'route' => ['schools.update', $school->id]
]) !!}  
     <div class="form-group">
        {!!Form::label('name', 'Name')!!}
         {{ Form::text('name', null, ['class'=>'form-control',
          'id'=>'name'])}} 
      </div>
   
  <div class="form-group">
    {!!Form::label('address', 'Address')!!}
     {{Form::text('address', null,['class'=>'form-control'])}}
  </div>
 <div class="form-group">
      {!! Form::submit('Update School', ['class'=>'btn btn-primary'])!!}
 
 </div>
 {!! Form::close() !!}
   
</div>
   </div>
</body>
</html>