<!DOCTYPE html>
<html>
<head>
<title>Crud example </title>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
    <div class="row">
      
 @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
@if(Session::has('flash_message'))
    <div class="alert alert-success">
        {{ Session::get('flash_message') }}
    </div>
@endif
   <fieldset>
    <legend class="col-lg-offset-4 col-lg-4">Create Nerd!!</legend>
    </fieldset>
    <p class="lead">Create the nerd below, or <a href="{{ route('nerds.index') }}">go back to all nerds.</a></p>
    {!! Form::open(['url' => 'nerds', 'method' => 'post' , 'class'=>'form-horizontal']) !!}
      <div class="form-group">
        {!!Form::label('name', 'Name')!!}
         {{ Form::text('name', '', ['class'=>'form-control',
          'placeholder'=>'Enter your name','id'=>'name'])}} 
      </div>
   <div class="form-group">
       {!!Form::label('email', 'Email')!!} 
       {{ Form::text('email', '', ['class'=>'form-control',
   ' placeholder'=>'Enter your email','id'=>'nerd level'])}} 
   </div>
    <div class="form-group">
       {!!Form::label('nerd_level', 'Nerd Level')!!} 
       {{ Form::text('nerd_level', '', ['class'=>'form-control',
   ' placeholder'=>'Enter your nerd level','id'=>'nerd level'])}} 
   </div>
   <div class="form-group">
      {!! Form::submit('Create Nerd', ['class'=>'btn btn-primary'])!!}
 
 </div>
 {!! Form::close() !!}
</div>
</body>
</html>