<!DOCTYPE html>
<html>
<head>
    <title>Show nerd</title>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container horizontal">
  <fieldset>
    <legend class="col-lg-offset-4 col-lg-4">View Nerd!!</legend>
    </fieldset>
<p class="lead">View the nerd below, or <a href="{{ route('nerds.index') }}">go back to all nerds.</a></p>
<h2>Name:{{ $nerd->name }}</h2>
    <h3><i>Id:</i>{{ $nerd->id}}</h3>
    <h3><i>Email:</i>{{ $nerd->email}}<h3>
    <h3><i>Level:</i>{{ $nerd->nerd_level}}</h3>
    <p>
<a href="{{ route('nerds.edit', $nerd->id) }}" class="btn btn-primary">Edit nerd</a>
<div>
        {!! Form::open([
            'method' => 'DELETE',
            'route' => ['nerds.destroy', $nerd->id]
        ]) !!}
            {!! Form::submit('Delete nerd', ['class' => 'btn btn-danger']) !!}
        {!! Form::close() !!}
    </div>
  </p>
</div>
</body>
</html>