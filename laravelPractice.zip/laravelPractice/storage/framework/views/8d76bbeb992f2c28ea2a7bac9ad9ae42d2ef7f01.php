<!DOCTYPE html>
<html>
<head>
    <title>Show student</title>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container horizontal">
  <fieldset>
    <legend class="col-lg-offset-4 col-lg-4">View Student!!</legend>
    </fieldset>
<p class="lead">View the student below, or <a href="<?php echo e(route('students.index')); ?>">go back to all students.</a></p>
<h2>Name:<?php echo e($student->name); ?></h2>
    <h3><i>Id:</i><?php echo e($student->id); ?></h3>
    <h3><i>Address:</i><?php echo e($student->address); ?><h3>
    <h3><i>Gender:</i><?php echo e($student->gender); ?></h3>
    <h3><i>Hobbies:</i><?php echo e($student->hobbies); ?></h3>
    <h3><i>Nationality:</i><?php echo e($student->nationality); ?></h3>
    <p>
<a href="<?php echo e(route('students.edit', $student->id)); ?>" class="btn btn-primary">Edit student</a>
<div>
        <?php echo Form::open([
            'method' => 'DELETE',
            'route' => ['students.destroy', $student->id]
        ]); ?>

            <?php echo Form::submit('Delete student', ['class' => 'btn btn-danger']); ?>

        <?php echo Form::close(); ?>

    </div>
  </p>
</div>
</body>
</html>