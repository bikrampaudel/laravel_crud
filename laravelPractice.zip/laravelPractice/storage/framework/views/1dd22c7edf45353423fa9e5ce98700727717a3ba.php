<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container">
		<div class="row">
			<legend>Students</legend>
			<?php if(session('info')): ?>
			<div class="alert alert-success"></div>
			<?php echo e(session('info')); ?>

			<?php endif; ?>
			<table class="table table-striped table-hover" >
				<thead>
					<tr>
						<th>ID</th>
						<th>Name</th>
						<th>Address</th>
						<th>Gender</th>
						<th>Hobbies</th>
						<th>Nationality</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php if(count($students)>0): ?>
						<?php $__currentLoopData = $students->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($student->id); ?></td>
								<td><?php echo e($student->name); ?></td>
								<td><?php echo e($student->address); ?></td>
								<td><?php echo e($student->gender); ?></td>
								<td><?php echo e($student->hobbies); ?></td>
								<td><?php echo e($student->nationality); ?></td>
								<td>
									<a href="/student/<?php echo e($student->id); ?>/edit" class="btn btn-success">edit</a>
									<?php echo e(Form::open(['method' => 'DELETE', 'route' => ['student.destroy', $student->id]])); ?>

   								 <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

								<?php echo e(Form::close()); ?>

									<!-- <a href="/student/<?php echo e($student->id); ?>" class="label label-danger">delete</a> -->
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</tbody>
			</table>

		</div>
	</div>

</body>
</html>