<!DOCTYPE html>
<html>
<head>
    <title>Show Teacher</title>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container horizontal">
  <fieldset>
    <legend class="col-lg-offset-4 col-lg-4">View Teacher!!</legend>
    </fieldset>
<p class="lead">View the teacher below, or <a href="<?php echo e(route('teachers.index')); ?>">go back to all teachers.</a></p>
<h2>Name:<?php echo e($teacher->name); ?></h2>
    <h3><i>Id:</i><?php echo e($teacher->id); ?></h3>
    <h3><i>Address:</i><?php echo e($teacher->address); ?><h3>
    
    <p>
<a href="<?php echo e(route('teachers.edit', $teacher->id)); ?>" class="btn btn-primary">Edit Teacher</a>
<div>
        <?php echo Form::open([
            'method' => 'DELETE',
            'route' => ['teachers.destroy', $teacher->id]
        ]); ?>

            <?php echo Form::submit('Delete Teacher', ['class' => 'btn btn-danger']); ?>

        <?php echo Form::close(); ?>

    </div>
  </p>
</div>
</body>
</html>