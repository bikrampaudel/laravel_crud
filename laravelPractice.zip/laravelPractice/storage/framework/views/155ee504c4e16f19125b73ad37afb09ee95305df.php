<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
This is about us page
<?php 
$i =5;
$j=5;
$k=6;

 ?>
<h1><?php echo e($i); ?></h1>
<h2><?php echo e($j); ?></h2>
<h3><?php echo e($k); ?></h3>
<?php if($i==1): ?>
<h1>one</h1>
<?php else: ?>
<h1>none</h1>
<?php endif; ?>

</body>
</html>