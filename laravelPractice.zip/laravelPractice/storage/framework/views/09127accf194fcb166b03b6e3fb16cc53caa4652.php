<!DOCTYPE html>
<html>
<head>
<title>Edit nerd </title>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
    <div class="row">
     <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php if(Session::has('flash_message')): ?>
    <div class="alert alert-success">
        <?php echo e(Session::get('flash_message')); ?>

    </div>
<?php endif; ?>
<h1>Editing "<?php echo e($nerd->name); ?>"</h1>
<p class="lead">Edit and save this nerd below, or <a href="<?php echo e(route('nerds.index')); ?>">go back to all nerds.</a></p>
<hr>
<?php echo Form::model($nerd, [
    'method' => 'PATCH',
    'route' => ['nerds.update', $nerd->id]
]); ?>

<div class="form-group">
    <?php echo Form::label('name', 'Name:', ['class' => 'control-label']); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('email', 'Email:', ['class' => 'control-label']); ?>

    <?php echo Form::text('email', null, ['class' => 'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('nerd_level', 'Nerd level:', ['class' => 'control-label']); ?>

    <?php echo Form::text('nerd_level', null, ['class' => 'form-control']); ?>

</div>
<?php echo Form::submit('Update Nerd', ['class' => 'btn btn-primary']); ?>

<?php echo Form::close(); ?>

</div>
</div>
</div>
</body>
</html>