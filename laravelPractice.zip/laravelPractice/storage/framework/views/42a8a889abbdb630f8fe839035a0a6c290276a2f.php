<!DOCTYPE html>
<html>
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
  <div class="container">
    <div class="row">
      
 
   <fieldset>
    <legend class="col-lg-offset-2 col-lg-2">Create Student</legend>
    </fieldset>
    <?php echo Form::open(['url' => 'student', 'method' => 'post' , 'class'=>'form-horizontal']); ?>

      <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
      <div class="form-group">
        <?php echo Form::label('name', 'Name'); ?>

         <?php echo e(Form::text('name', '', ['class'=>'form-control',
          'placeholder'=>'Enter your name','id'=>'name'])); ?> 
      </div>
   <div class="form-group">
       <?php echo Form::label('address', 'Address'); ?> 
       <?php echo e(Form::text('address', '', ['class'=>'form-control',
   ' placeholder'=>'Enter your address','id'=>'address'])); ?> 
   </div>
    <div class="form-group">
      
     <?php echo Form::label('Gender', 'Gender'); ?>

        <div class="radio-inline"><label> 
          <?php echo Form::radio('gender', 'male', true,['id'=>'optionsRadios1']); ?> Male</label></div>
        <div class="radio-inline"><label> 
          <?php echo Form::radio('gender', 'female', false,['id'=>'optionsRadios1']); ?> Female</label></div>
        <div class="radio-inline"><label> <?php echo Form::radio('gender', 'none', false,['id'=>'optionsRadios1']); ?> None</label></div>
      </div>
  
  
  <div class="form-group">
     <?php echo Form::label('hobbies', 'Hobbies'); ?> <br />
     <?php echo Form::checkbox('hobbies', 'playing', '',['class'=>'col-lg-0']); ?>Playing <br />
    <?php echo e(Form::checkbox('hobbies', 'programming' ,'',['class'=>'col-lg-0'])); ?> Programming <br />
     <?php echo e(Form::checkbox('hobbies', 'dancing' , '', ['class'=>'col-lg-0'])); ?> Dancing <br />
  </div>
  <div class="form-group">
    <?php echo Form::label('nationality', 'Nationality'); ?>

     <?php echo e(Form::select('nationality',['nepal'=>'Nepali','india'=>'Indian','america'=>'American'],'nepal',['class'=>'form-control'])); ?>

  </div>
 <div class="form-group">
      <?php echo Form::submit('Add Student', ['class'=>'btn btn-primary']); ?>

 
 </div>
 <?php echo Form::close(); ?>

   
</div>
   </div>
</body>
</html>