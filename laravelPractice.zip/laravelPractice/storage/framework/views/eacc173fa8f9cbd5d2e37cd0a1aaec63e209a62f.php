<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<table>
<?php $__currentLoopData = $height; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name =>$h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $weight; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name =>$w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($name); ?></td>
<td><?php echo e($h); ?></td>
<td><?php echo e($h); ?></td>
	

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</body>
</html>