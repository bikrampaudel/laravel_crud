<!DOCTYPE html>
<html>
<head>
    <title>Show nerd</title>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container horizontal">
  <fieldset>
    <legend class="col-lg-offset-4 col-lg-4">View Nerd!!</legend>
    </fieldset>
<p class="lead">View the nerd below, or <a href="<?php echo e(route('nerds.index')); ?>">go back to all nerds.</a></p>
<h2>Name:<?php echo e($nerd->name); ?></h2>
    <h3><i>Id:</i><?php echo e($nerd->id); ?></h3>
    <h3><i>Email:</i><?php echo e($nerd->email); ?><h3>
    <h3><i>Level:</i><?php echo e($nerd->nerd_level); ?></h3>
    <p>
<a href="<?php echo e(route('nerds.edit', $nerd->id)); ?>" class="btn btn-primary">Edit nerd</a>
<div>
        <?php echo Form::open([
            'method' => 'DELETE',
            'route' => ['nerds.destroy', $nerd->id]
        ]); ?>

            <?php echo Form::submit('Delete nerd', ['class' => 'btn btn-danger']); ?>

        <?php echo Form::close(); ?>

    </div>
  </p>
</div>
</body>
</html>