<!DOCTYPE html>
<html>
<head>
    <title>Show Teacher</title>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container horizontal">
  <fieldset>
    <legend class="col-lg-offset-4 col-lg-4">View School!!</legend>
    </fieldset>
<p class="lead">View the school below, or <a href="<?php echo e(route('schools.index')); ?>">go back to all schools.</a></p>
<h2>Name:<?php echo e($school->name); ?></h2>
    <h3><i>Id:</i><?php echo e($school->id); ?></h3>
    <h3><i>Address:</i><?php echo e($school->address); ?><h3>
    
    <p>
<a href="<?php echo e(route('schools.edit', $school->id)); ?>" class="btn btn-primary">Edit School</a>
<div>
        <?php echo Form::open([
            'method' => 'DELETE',
            'route' => ['schools.destroy', $school->id]
        ]); ?>

            <?php echo Form::submit('Delete School', ['class' => 'btn btn-danger']); ?>

        <?php echo Form::close(); ?>

    </div>
  </p>
</div>
</body>
</html>