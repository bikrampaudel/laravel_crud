<?php

namespace Larabook;

use Illuminate\Database\Eloquent\Model;

class Teacher extends Model
{
   protected $fillable = [
   		'name', 'address'
   ];
}
