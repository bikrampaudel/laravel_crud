<?php

namespace Larabook;

use Illuminate\Database\Eloquent\Model;

class student extends Model
{
    protected $fillable = [

    		'name', 'address', 'gender','hobbies','nationality'



    ];
}
