<?php

namespace Larabook\Http\Controllers;

use Illuminate\Http\Request;
use Larabook\Grade;
//use app\Nerd;
use Larabook\Http\Requests\GradeRequest;
use Session;

class GradeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $grades = Grade::all();

        
        return view('grades.indexGrade', compact('grades'));
       
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return View('grades.createGrade');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(GradeRequest $request)
    {
        
        $input=$request->all();
        Grade::create($input);
        
        Session::flash('flash_message', 'Grade successfully created!');
       return redirect()->back();
        
    }



    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
    //    $nerd = Nerd::findOrFail($id);

    // return view('nerds.show')->withTask($nerd);
     $grade = Grade::findOrFail($id);

        // load the view and pass the nerds
        return view('grades.showGrade', compact('grade'));
            
    }
    

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $grade = Grade::find($id);
        
        return view('grades.editGrade', compact('grade','id'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
     $grade = Grade::findOrFail($id);
     $input = $request->all();

    $grade->fill($input)->save();
    Session::flash('flash_message', 'Grade successfully updated!');

     return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
    $grade = Grade::findOrFail($id);

    $grade->delete();

    Session::flash('flash_message', 'Grade successfully deleted!');

    return redirect()->route('grades.index');
    }
}
