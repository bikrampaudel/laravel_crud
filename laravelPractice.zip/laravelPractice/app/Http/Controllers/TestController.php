<?php

namespace Larabook\Http\Controllers;

use Illuminate\Http\Request;

class TestController extends Controller
{
    public function showTestView ()
    {
    	return view('test');
    }
}

