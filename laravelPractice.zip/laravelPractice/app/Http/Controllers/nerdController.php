<?php

namespace Larabook\Http\Controllers;

use Illuminate\Http\Request;
use Larabook\Nerd;
//use app\Nerd;
use Larabook\Http\Requests\NerdRequest;
use Session;

class nerdController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $nerds = Nerd::all();

        // load the view and pass the nerds
        return view('nerds.indexNerd', compact('nerds'));
        //Larabook\Nerd::create(Input::all())
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return View('nerds.createNerd');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(NerdRequest $request)
    {
        
        $input=$request->all();
        Nerd::create($input);
        
        Session::flash('flash_message', 'Nerd successfully created!');
       return redirect()->back();
        
    }



    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
    //    $nerd = Nerd::findOrFail($id);

    // return view('nerds.show')->withTask($nerd);
     $nerd = Nerd::findOrFail($id);

        // load the view and pass the nerds
        return view('nerds.showNerd', compact('nerd'));
            
    }
    

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $nerd = Nerd::find($id);
        
        return view('nerds.editNerd', compact('nerd','id'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
     $nerd = Nerd::findOrFail($id);
     $input = $request->all();

    $nerd->fill($input)->save();
    Session::flash('flash_message', 'Nerd successfully updated!');

     return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
    $nerd = Nerd::findOrFail($id);

    $nerd->delete();

    Session::flash('flash_message', 'Nerd successfully deleted!');

    return redirect()->route('nerds.index');
    }
}
