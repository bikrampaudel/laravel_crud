<?php

namespace Larabook\Http\Controllers;

use Illuminate\Http\Request;
use Larabook\Teacher;
//use app\Nerd;
use Larabook\Http\Requests\TeacherRequest;
use Session;

class TeacherController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $teachers = Teacher::all();

        
        return view('teachers.indexTeacher', compact('teachers'));
       
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return View('teachers.createTeacher');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(TeacherRequest $request)
    {
        
        $input=$request->all();
        Teacher::create($input);
        
        Session::flash('flash_message', 'Teacher successfully created!');
       return redirect()->back();
        
    }



    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
    //    $nerd = Nerd::findOrFail($id);

    // return view('nerds.show')->withTask($nerd);
     $teacher = Teacher::findOrFail($id);

        // load the view and pass the nerds
        return view('teachers.showTeacher', compact('teacher'));
            
    }
    

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $teacher = Teacher::find($id);
        
        return view('teachers.editTeacher', compact('teacher','id'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
     $teacher = Teacher::findOrFail($id);
     $input = $request->all();

    $teacher->fill($input)->save();
    Session::flash('flash_message', 'Teacher successfully updated!');

     return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
    $teacher = Teacher::findOrFail($id);

    $teacher->delete();

    Session::flash('flash_message', 'Teacher successfully deleted!');

    return redirect()->route('teachers.index');
    }
}
