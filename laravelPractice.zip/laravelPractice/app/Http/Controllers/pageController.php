<?php

namespace Larabook\Http\Controllers;

use Illuminate\Http\Request;

class pageController extends Controller
{
     public function showHomeView ()
    {
    	$height=array(
    			'ram' =>5.5 ,
    			'shyam' => 6.6,
    			'Anil' =>5.7
    			);
    	$weight=array(
    		'ram' => 50,
    		'shyam'=>60,
    		'Anil '=>70
    		);

    	return view('home', compact('height','weight'));
    }
     public function showAboutView ()
    {
    	return view('about');
    }
}
