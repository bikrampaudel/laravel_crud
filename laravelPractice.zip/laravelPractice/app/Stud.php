<?php

namespace Larabook;

use Illuminate\Database\Eloquent\Model;

class Stud extends Model
{
   
}
